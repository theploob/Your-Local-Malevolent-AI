import discord

# IMBLYIGN
async def entry(cmdArgs, message):
    await message.channel.send(file=discord.File('implying.jpg'))
