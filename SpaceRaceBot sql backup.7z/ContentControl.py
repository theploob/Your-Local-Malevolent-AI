bannedWordList = {
    'nigger',
    'n1gger',
    'n1gg3r'
}
